//Clase principal de la aplicación.
package co.edu.unbosque.controller;

public class AplMain {
public static void main(String[] args) {
	Controlador con = new Controlador(); // Crea una instancia del controlador.
	con.run(); // Ejecuta el controlador.
}
}
